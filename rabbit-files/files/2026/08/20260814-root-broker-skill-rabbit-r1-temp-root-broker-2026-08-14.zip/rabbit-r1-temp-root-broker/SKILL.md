---
name: rabbit-r1-temp-root-broker
description: Guide safe, stock-preserving Rabbit r1 temporary-root and privileged broker work. Use for rabbitOS ADB enablement, root-session planning, Preloader/WebUSB/MTKClient validation, Rabbit Glide APK deployment blockers, or designing a local broker that can run privileged commands without persistent boot/system/vendor/super changes.
---

# Rabbit R1 Temp Root Broker

## Core rule

Preserve stock rabbitOS and hardware behavior. Treat temporary root as a RAM-only session used to enable an authorized ADB/deployment path, not as a permanent modification.

Never run device, ADB, fastboot, Preloader, flashing, boot-slot, root, APK-install, or IME-setting commands unless the user explicitly authorizes that exact action in the current turn and live state has been rechecked.

## Required context

For Rabbit r1 work in `/Users/z3k3z/Documents/Omi Dev Space`, first read:

1. `/Users/z3k3z/Documents/AgentSharedMemory/shared/SOURCE-OF-TRUTH.md`
2. `/Users/z3k3z/Documents/AgentSharedMemory/shared/session-index.json`
3. Newest file under `/Users/z3k3z/Documents/AgentSharedMemory/shared/snapshots/`
4. `/Users/z3k3z/Documents/Omi Dev Space/rabbit-glide-keyboard/PROJECT-HANDOFF.md`

Use memory-derived facts only as stale context. Recheck live screen, USB mode, serial, slot, and build before any device action.

## Current approved design

Use a three-part architecture:

1. Mac-side bootstrap launcher: enters a RAM-only temporary-root session through a build-compatible Preloader/WebUSB/MTKClient/Carroot-style path.
2. r1-side privileged broker: runs only while temporary root is active and exposes a narrow API for approved privileged actions.
3. Creation/control UI: displays status and requests actions from the broker; it cannot grant root, ADB, storage, fastboot, recovery, or shell by itself.

Temporary root must disappear after reboot unless the user separately approves persistent root.

## Hard blockers

Stop and explain the blocker if any of these are true:

- Exact device serial is not confirmed as the intended r1.
- Current slot is not the preserved safe slot, or slot state is unknown.
- Current rabbitOS/LK/preloader build is unknown.
- The payload is not validated for the exact current build.
- The plan writes `boot`, `vbmeta`, `super`, `vendor`, slot A, GPT, or userdata.
- The plan uses the hosted/public Carroot payload unchanged.
- The plan grants ADB to any connected host instead of an allowlisted host key.
- The plan relies on a Rabbit Creation/WebView alone for privileged work.
- There is no cleanup path and stock reboot verification.

## Safe workflow

1. Read federated context and project handoff.
2. Review current public documentation if the question depends on current rabbitOS/root/firmware behavior.
3. Inspect local tooling only with read-only commands until the user authorizes live device actions.
4. Build or review the broker plan against `references/broker-contract.md`.
5. Validate the plan using `scripts/validate_plan.py`.
6. For live testing, require:
   - normal stock slot-A boot since the last low-level attempt;
   - normal shutdown before Preloader;
   - fresh browser/bridge process;
   - fresh USB enumeration;
   - explicit action-time approval.
7. First live test must be read-only identity/compatibility. Do not enable root/ADB during the first compatibility check.
8. If compatibility passes, start a RAM-only root session and launch the broker.
9. Enable only the requested capability, preferably USB ADB for the known Mac host.
10. Verify result, run cleanup, reboot stock, and verify root/broker are gone unless persistence was explicitly approved.

## Broker capability boundaries

Allowed during an approved temporary-root session:

- report broker/root/ADB/USB/IME status;
- add one known Mac ADB public key;
- enable/disable USB ADB;
- optionally enable ADB TCP/IP only after USB authorization;
- install the no-permission ADB canary;
- install Rabbit Glide;
- enable/set/revert the Rabbit Glide IME;
- collect logs needed for diagnosis;
- run explicit shell commands approved for the task.

Rejected by default:

- authorize any connected device;
- expose root shell to the network without authentication;
- persist Magisk/root;
- patch or flash the boot chain;
- bypass OTA/update mechanisms;
- alter stock Rabbit services unless a reversible, tested rollback exists.

## References

- Read `references/research-summary.md` when explaining known public methods.
- Read `references/broker-contract.md` when designing or reviewing broker APIs.
- Use `scripts/validate_plan.py` to reject unsafe JSON plans before live action.
