#!/usr/bin/env python3
"""Validate a Rabbit r1 temporary-root broker plan before live device action.

Input: JSON file with keys such as:
{
  "device_serial": "919109A6U160125811C7",
  "memory_only": true,
  "exact_build_validated": true,
  "fresh_boot_cycle_confirmed": true,
  "host_key_allowlist": ["SHA256:..."],
  "actions": ["read_identity", "enable_usb_adb"],
  "writes_partitions": [],
  "uses_public_carroot_unchanged": false,
  "authorizes_any_device": false,
  "cleanup_plan": true
}
"""

from __future__ import annotations

import json
import sys
from pathlib import Path


FORBIDDEN_ACTIONS = {
    "flash_boot",
    "flash_vbmeta",
    "flash_super",
    "flash_vendor",
    "flash_system",
    "erase_userdata",
    "set_active_slot_b",
    "persistent_magisk",
    "persistent_root",
    "authorize_any_device",
}

FORBIDDEN_PARTITIONS = {
    "boot",
    "boot_a",
    "vbmeta",
    "vbmeta_a",
    "super",
    "vendor",
    "vendor_a",
    "system",
    "system_a",
    "userdata",
    "gpt",
}


def fail(message: str) -> None:
    print(f"FAIL: {message}")
    raise SystemExit(1)


def main() -> None:
    if len(sys.argv) != 2:
        fail("usage: validate_plan.py <plan.json>")

    plan_path = Path(sys.argv[1])
    plan = json.loads(plan_path.read_text())

    if not plan.get("device_serial"):
        fail("device_serial is required")

    if plan.get("memory_only") is not True:
        fail("memory_only must be true")

    if plan.get("exact_build_validated") is not True:
        fail("exact_build_validated must be true")

    if plan.get("fresh_boot_cycle_confirmed") is not True:
        fail("fresh_boot_cycle_confirmed must be true before low-level sessions")

    if plan.get("uses_public_carroot_unchanged"):
        fail("public/hosted Carroot payload cannot be used unchanged")

    if plan.get("authorizes_any_device"):
        fail("authorizing any connected device is rejected")

    actions = set(plan.get("actions", []))
    bad_actions = sorted(actions & FORBIDDEN_ACTIONS)
    if bad_actions:
        fail(f"forbidden actions requested: {', '.join(bad_actions)}")

    writes = {str(item).lower() for item in plan.get("writes_partitions", [])}
    bad_writes = sorted(writes & FORBIDDEN_PARTITIONS)
    if bad_writes:
        fail(f"forbidden partition writes requested: {', '.join(bad_writes)}")

    if "enable_usb_adb" in actions:
        allowlist = plan.get("host_key_allowlist", [])
        if not allowlist:
            fail("enable_usb_adb requires host_key_allowlist")

    if plan.get("cleanup_plan") is not True:
        fail("cleanup_plan must be true")

    print("OK: plan passes Rabbit r1 temporary-root broker safety validation")


if __name__ == "__main__":
    main()
