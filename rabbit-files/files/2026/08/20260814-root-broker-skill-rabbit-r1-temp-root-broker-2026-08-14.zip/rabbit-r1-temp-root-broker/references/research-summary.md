# Rabbit r1 temporary-root research summary

Last reviewed: 2026-08-14.

## Public methods found

### Official Rabbit developer mode and Flash Tool

Rabbit's official developer-mode path enables bootloader unlock and stock flashing through the Rabbit R1 Flash Tool. It does not document ordinary stock rabbitOS USB debugging enablement or Android Developer Options. Rabbit says developer mode/bootloader unlock voids warranty and that stock rabbitOS can be restored with the Flash Tool.

Primary references:

- https://www.rabbit.tech/support/article/unlock-bootloader-rabbit-r1
- https://rabbit-hmi-oss.github.io/flashing/

### r1_escape

`RabbitHoleEscapeR1/r1_escape` uses MediaTek Preloader tooling and custom images to escape stock rabbitOS into a more conventional Android/userdebug path. It is useful as prior art for Preloader/MTK flow and `mtkbootcmd.py`, but it is not stock-preserving. Its public flow includes unlocking, disabling AVB, and flashing images.

Reference:

- https://github.com/RabbitHoleEscapeR1/r1_escape

### rabbitMods / userdebug builds

rabbitMods documentation assumes a modded/userdebug environment where USB debugging and rooted debugging can be enabled through Android settings, then `adb root` can provide root shell access. This is not an entry point for stock rabbitOS when Android Developer Options are unavailable.

References:

- https://www.rabbitmods.net/
- https://www.rabbitmods.net/troubleshooting/
- https://www.rabbitmods.net/flashing/

### CipherOS and other custom firmware

Rabbit R1 custom firmware work shows ADB over USB and more Android-like configuration are achievable after replacing stock software, but it can lose stock hardware behavior. One reviewed firmware guide reports the side/power/PTT button does not generate interrupts on CipherOS. That violates the project constraint.

Reference:

- https://github.com/TurboTheTurtle/rabbit-r1-firmware

## Current project conclusion

No reviewed public method currently proves a stock-preserving, rabbitOS 2.3-compatible, memory-only root payload for the exact project build. The safest route is to create a device/build-specific RAM-only bootstrap and broker, with the first test limited to read-only identity and compatibility.

Do not run hosted/public Carroot payloads unchanged. Do not substitute v0.8.293 compatibility for a newer rabbitOS 2.3 LK/preloader identity.

## Practical implication

The Rabbit Creation can be a UI. It cannot grant root, USB ADB, USB storage, FTP, fastboot, recovery, or shell by itself. A separate privileged broker must already be running from a temporary root session.
